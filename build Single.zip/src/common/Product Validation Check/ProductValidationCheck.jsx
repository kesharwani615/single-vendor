import React from 'react'

const useProductValidationCheck = () => {
    const CheckEachField = () =>{

    }

  return { CheckEachField }
}

export default useProductValidationCheck
