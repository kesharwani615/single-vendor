import React from 'react'
import { Outlet } from 'react-router-dom'

const ProductForCommanOutelet = () => {
  return (
    <>
      <Outlet/>
    </>
  )
}

export default ProductForCommanOutelet
