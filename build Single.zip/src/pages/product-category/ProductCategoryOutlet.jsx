import React from 'react'
import { Outlet } from 'react-router-dom'

const ProductCategoryOutlet = () => {
  return (
    <>
     <Outlet/> 
    </>
  )
}

export default ProductCategoryOutlet
