import React from 'react'
import { Outlet } from 'react-router-dom'

const UserManagementOutlet = () => {
  return (
    <>
     <Outlet/> 
    </>
  )
}

export default UserManagementOutlet
