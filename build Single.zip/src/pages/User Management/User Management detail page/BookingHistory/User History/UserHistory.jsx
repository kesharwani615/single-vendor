import React from 'react'

const UserHistory = () => {
  return (
    <>
     
    <div className="OrderDetails">
      <h5>Booking Details</h5>
      <article>
        <aside>
          <p>
            <label>Booking Number</label>
            <span>U-030</span>
          </p>
          <p>
            <label>Placed On</label>
            <span>01/01/2023 &amp; 01:01</span>
          </p>
        </aside>
        <aside>
          <p>
            <label>Payment Status</label>
            <span>Cancelled</span>
          </p>
          <p>
            <label>Total Amount</label>
            <span>Rs. 1,512.00</span>
          </p>
        </aside>
      </article>
    </div>
    <div className="OrderDetails">
      <h5>Item(s) List</h5>
      <article>
        <figure>
          <img src="images/Avatar-2.png" />
        </figure>
        <aside>
          <p>
            <label>Name of the product</label>
            <span>lorem</span>
          </p>
        </aside>
        <aside>
          <p>
            <label>Qty</label>
            <span>1</span>
          </p>
          {/* <p>
                      <label>Size</label>
                      <span>lorem</span>
                  </p> */}
        </aside>
      </article>
      <article>
        <figure>
          <img src="images/Avatar-2.png" />
        </figure>
        <aside>
          <p>
            <label>Name of the product</label>
            <span>lorem</span>
          </p>
        </aside>
        <aside>
          <p>
            <label>Qty</label>
            <span>1</span>
          </p>
          {/* <p>
                      <label>Size</label>
                      <span>lorem</span>
                  </p> */}
        </aside>
      </article>
    </div>
    <div className="OrderDetails">
      <h5>Venue Address</h5>
      <article>
        <aside>
          <p>
            <label>Full Name</label>
            <span>Rahul Bhawaliya</span>
          </p>
          <p>
            <label>Mobile Number</label>
            <span>(+91 9865321470)</span>
          </p>
          <p>
            <label>Address</label>
            <span>
              House Number/Flat No./Office No. <br />
              Road name, Area Name, Society Name <br />
              City, Region, Country <br />
              Pin Code
            </span>
          </p>
        </aside>
      </article>
    </div>
    <div className="OrderDetails">
      <h5>Decorator Partner Details</h5>
      <article>
        <aside>
          <p>
            <label>Name</label>
            <span>Raghav</span>
          </p>
          <p>
            <label>Tracking Id or Number</label>
            <span>12367</span>
          </p>
          <p>
            <label>Contact Number</label>
            <span>(+91 9865321470)</span>
          </p>
        </aside>
      </article>
    </div>
    <div className="OrderDetails">
      <h5>Price Details</h5>
      <article>
        <aside>
          <p>
            <label>Total Amount</label>
            <span>Rs. 100.00</span>
          </p>
          <p>
            <label>GST</label>
            <span>10%</span>
          </p>
          {/* <p>
                      <label>Decorator Charges</label>
                      <span>Rs. 10.00</span>
                  </p> */}
          <hr />
          <p>
            <label>You Pay</label>
            <span>Rs. 90.00</span>
          </p>
        </aside>
      </article>
    </div>
    <div className="OrderDetails">
      <h5>Ratings &amp; Reviews</h5>
      <article>
        <aside>
          <p>
            <label>Rating</label>
            <span>4.5 Stars</span>
          </p>
          <p>
            <label>Comment</label>
            <span>lorem</span>
          </p>
        </aside>
      </article>
    </div>
    <div className="OrderDetails">
      <h5>Booking Status</h5>
      <article>
        <a href="#">Delivered | Cancelled | In-Transit</a>
      </article>
</div>
 
    </>
  )
}

export default UserHistory
