import React from 'react'
import { Outlet } from 'react-router-dom'

const AbandonedCartOutletCommon = () => {
  return (
    <>
     <Outlet/> 
    </>
  )
}

export default AbandonedCartOutletCommon