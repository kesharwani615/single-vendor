import React from 'react'
import { Outlet } from 'react-router-dom'

const ContentManagementOutlet = () => {
  return (
    <>
     <Outlet/> 
    </>
  )
}

export default ContentManagementOutlet
